# SATHI Project

This project has:
- **Backend** → Python API (Flask/FastAPI)
- **Frontend** → Static site (HTML, CSS, JS)

### Deployment
- Backend deployed on Render
- Frontend deployed on Netlify
